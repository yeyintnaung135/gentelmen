<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FaqQuestion extends Model
{
    //
    protected $fillable = [
        'name','title'
    ];
}
