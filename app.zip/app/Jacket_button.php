<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jacket_Button extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
