<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MainTexture extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
