<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdditionalSubCategory extends Model
{
    //
    protected $fillable = [
        'name','main_additional_id'
    ];
}
