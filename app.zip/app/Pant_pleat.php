<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pant_pleat extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
