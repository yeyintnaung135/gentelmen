<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TemporaryCustomizeStep extends Model
{
    //
    protected $fillable = [
      'user_id','step'
  ];
}
