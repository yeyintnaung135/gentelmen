<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vest_lapel extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
