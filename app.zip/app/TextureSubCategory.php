<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TextureSubCategory extends Model
{
    //
    protected $fillable = [
        'main_texture_id','name'
    ];
}
