<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegisterLog extends Model
{
    //
    protected $fillable = [
        'name', 'email',
    ];

}
