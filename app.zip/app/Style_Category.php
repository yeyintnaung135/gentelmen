<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Style_Category extends Model
{
    //
    protected $fillable = [
        'name'
    ];
}
