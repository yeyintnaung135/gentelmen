<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomizeCategory extends Model
{
    //
    protected $fillable = [
      'name','file'
  ];
}
