<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FaqTitle extends Model
{
    //
    protected $fillable = [
        'name','title'
    ];
}
